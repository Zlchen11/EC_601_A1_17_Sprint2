# Recoveries Test

Provides some simple tests for recovery plugins. 
It creates an instance of the stack, with the recovery server loading different recovery plugins, and checks for successful recovery behaviors.
